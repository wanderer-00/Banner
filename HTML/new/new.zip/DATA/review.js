var data_reviews = [
    {
        "NAME": "Royan Rten",
        "ICON": "1.jpg",
        "STAR": 5,
        "NOTE": "Я анимешник"
    },
    {
        "NAME": "Shrek 1990",
        "ICON": "2.jpg",
        "STAR": 0.5,
        "NOTE": "Lorem ipsum dolor sit amet, consectetur adipisicing elit. Inventore veniam iste cumque. Minima tempore harum fuga facere impedit odio reiciendis, consequuntur soluta, pariatur vero illum, aut dolor magnam aliquid mollitia"
    },
    {
        "NAME": "Петя Маслеников",
        "ICON": "3.webp",
        "STAR": 2.5,
        "NOTE": "Lorem ipsum dolor sit amet, consectetur adipisicing elit. Inventore veniam ionsectetur adipisicing elit. Inventore veniam iste cumque. Minima tempore haruonsectetur adipisicing elit. Inventore veniam iste cumque. Minima tempore haruonsectetur adipisicing elit. Inventore veniam iste onsectetur adipisicing elit. Inventore veniam iste cumque. Minima tempore haruonsectetur adipisicing elit. Inventore veniam iste cumque. Minima tempore haruonsectetur adipisicing elit. Inventore veniam iste cumque. Minima tempore haruonsectetur adipisicing elit. Inventore veniam iste cumqueonsectetur adipisicing elit. Inventore veniam iste cumque. Minima tempore haru. Minima tempore harucumque. Minima tempore haruste cumque. Minima tempore harum fuga facere impedit odio reiciendis, consequuntur soluta, pariatur vero illum, aut dolor magnam aliquid mollitia"
    }
]