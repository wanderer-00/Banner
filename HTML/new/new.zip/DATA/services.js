var data_services = [
    {
        "ICON": "banner.png",
        "NAME": "Банеры"
    },
    {
        "ICON": "sticker.jpg",
        "NAME": "Наклейки"
    },
    {
        "ICON": "poster.jpg",
        "NAME": "Постеры"
    },
    {
        "ICON": "plotter_cutting.png",
        "NAME": "Плотерная резка"
    },
    {
        "ICON": "milling.png",
        "NAME": "Фрезеровка хэштега"
    },
    {
        "ICON": "mobile_design.jpg",
        "NAME": "Мобильные конструкции"
    },
    {
        "ICON": "table.jpg",
        "NAME": "Таблички"
    },
    {
        "ICON": "design.png",
        "NAME": "Дизайн"
    }
]